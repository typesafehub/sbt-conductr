#!/bin/bash

echo "I am configured"
